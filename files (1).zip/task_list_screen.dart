import 'package:flutter/material.dart';
import '../task.dart';
import '../widgets/task_card.dart';
import 'task_detail_screen.dart';

class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  // Master list of all tasks
  final List<Task> _allTasks = [
    // Sample tasks so the app doesn't open empty
    Task(
      title: 'Submit Flutter Assignment',
      description: 'Complete and submit the major Flutter exercise before the deadline.',
      category: 'School',
      priority: 'High',
      dueDate: DateTime(2026, 5, 16),
    ),
    Task(
      title: 'Buy groceries',
      description: 'Rice, tomatoes, cooking oil, and vegetables.',
      category: 'Personal',
      priority: 'Low',
      dueDate: DateTime(2026, 5, 17),
    ),
    Task(
      title: 'Morning jog',
      description: 'Run 3km around the campus track before breakfast.',
      category: 'Health',
      priority: 'Medium',
      dueDate: DateTime(2026, 5, 15),
    ),
  ];

  // UI state variables
  String _activeFilter = 'All';    // 'All' | 'Pending' | 'Completed'
  String _sortMode = 'Date';       // 'Date' | 'Priority'
  String _searchQuery = '';        // Text typed in the search bar
  bool _isSearching = false;       // Whether search bar is visible

  // TextEditingControllers hold the text inside form fields
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descController = TextEditingController();

  // Form field values for the Add/Edit bottom sheet
  String _selectedCategory = 'School';
  String _selectedPriority = 'Medium';
  DateTime? _selectedDueDate;

  // Categories and priorities available in dropdowns
  final List<String> _categories = ['School', 'Personal', 'Health', 'Work', 'Finance'];
  final List<String> _priorities = ['Low', 'Medium', 'High'];

  // ── Computed property: returns filtered + sorted list ──
  List<Task> get _displayedTasks {
    // Step 1: filter by active tab
    List<Task> filtered = _allTasks.where((task) {
      if (_activeFilter == 'Pending') return !task.isCompleted;
      if (_activeFilter == 'Completed') return task.isCompleted;
      return true; // 'All'
    }).toList();

    // Step 2: filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered
          .where((task) =>
              task.title.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    }

    // Step 3: sort the resulting list
    filtered.sort((a, b) {
      if (_sortMode == 'Date') {
        return a.dueDate.compareTo(b.dueDate); // Earliest first
      } else {
        // Priority order: High=0, Medium=1, Low=2 — lower index = higher priority
        const order = {'High': 0, 'Medium': 1, 'Low': 2};
        return (order[a.priority] ?? 1).compareTo(order[b.priority] ?? 1);
      }
    });

    return filtered;
  }

  // ── Statistics ──
  int get _totalCount => _allTasks.length;
  int get _completedCount => _allTasks.where((t) => t.isCompleted).length;
  int get _pendingCount => _totalCount - _completedCount;
  double get _completionRate =>
      _totalCount == 0 ? 0.0 : _completedCount / _totalCount;

  @override
  void dispose() {
    // Always dispose controllers to free memory
    _searchController.dispose();
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  // ── Toggle a task's completion status ──
  void _toggleTask(Task task) {
    setState(() {
      task.isCompleted = !task.isCompleted;
    });
  }

  // ── Delete a single task ──
  void _deleteTask(Task task) {
    setState(() {
      _allTasks.remove(task);
    });
  }

  // ── Delete ALL tasks after confirmation ──
  void _clearAllTasks() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Tasks'),
        content: const Text(
            'This will permanently delete all tasks. Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() => _allTasks.clear());
              Navigator.pop(ctx);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete All'),
          ),
        ],
      ),
    );
  }

  // ── Opens the bottom sheet for adding OR editing a task ──
  void _openTaskForm({Task? existingTask}) {
    // If editing, pre-fill the controllers with existing data
    if (existingTask != null) {
      _titleController.text = existingTask.title;
      _descController.text = existingTask.description;
      _selectedCategory = existingTask.category;
      _selectedPriority = existingTask.priority;
      _selectedDueDate = existingTask.dueDate;
    } else {
      // Adding new task — start with empty fields
      _titleController.clear();
      _descController.clear();
      _selectedCategory = 'School';
      _selectedPriority = 'Medium';
      _selectedDueDate = null;
    }

    final formKey = GlobalKey<FormState>(); // Used for validation

    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Lets the sheet grow taller
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        // StatefulBuilder allows setState inside the bottom sheet
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Padding(
              // viewInsets.bottom pushes the sheet up when keyboard appears
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Sheet title
                      Text(
                        existingTask != null ? 'Edit Task' : 'Add New Task',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Title field
                      TextFormField(
                        controller: _titleController,
                        decoration: _inputDecoration('Task Title', Icons.title),
                        validator: (val) =>
                            val == null || val.isEmpty ? 'Title is required' : null,
                      ),
                      const SizedBox(height: 12),

                      // Description field
                      TextFormField(
                        controller: _descController,
                        decoration:
                            _inputDecoration('Description', Icons.description),
                        maxLines: 2,
                        validator: (val) =>
                            val == null || val.isEmpty
                                ? 'Description is required'
                                : null,
                      ),
                      const SizedBox(height: 12),

                      // Category dropdown
                      DropdownButtonFormField<String>(
                        value: _selectedCategory,
                        decoration:
                            _inputDecoration('Category', Icons.category),
                        items: _categories
                            .map((c) =>
                                DropdownMenuItem(value: c, child: Text(c)))
                            .toList(),
                        onChanged: (val) =>
                            setSheetState(() => _selectedCategory = val!),
                        validator: (val) =>
                            val == null ? 'Select a category' : null,
                      ),
                      const SizedBox(height: 12),

                      // Priority dropdown
                      DropdownButtonFormField<String>(
                        value: _selectedPriority,
                        decoration:
                            _inputDecoration('Priority', Icons.flag_outlined),
                        items: _priorities
                            .map((p) =>
                                DropdownMenuItem(value: p, child: Text(p)))
                            .toList(),
                        onChanged: (val) =>
                            setSheetState(() => _selectedPriority = val!),
                        validator: (val) =>
                            val == null ? 'Select a priority' : null,
                      ),
                      const SizedBox(height: 12),

                      // Due date picker button
                      GestureDetector(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _selectedDueDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2030),
                          );
                          if (picked != null) {
                            setSheetState(() => _selectedDueDate = picked);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 14),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.shade400),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.calendar_today,
                                  size: 18, color: Colors.grey),
                              const SizedBox(width: 10),
                              Text(
                                _selectedDueDate == null
                                    ? 'Pick a due date'
                                    : _formatDate(_selectedDueDate!),
                                style: TextStyle(
                                  color: _selectedDueDate == null
                                      ? Colors.grey
                                      : Colors.black87,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Save button
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2E7D32),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          onPressed: () {
                            // Validate all form fields
                            if (!formKey.currentState!.validate()) return;
                            if (_selectedDueDate == null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Please pick a due date')),
                              );
                              return;
                            }

                            setState(() {
                              if (existingTask != null) {
                                // Update the existing task in-place
                                existingTask.title = _titleController.text.trim();
                                existingTask.description =
                                    _descController.text.trim();
                                existingTask.category = _selectedCategory;
                                existingTask.priority = _selectedPriority;
                                existingTask.dueDate = _selectedDueDate!;
                              } else {
                                // Add a brand new task to the list
                                _allTasks.add(Task(
                                  title: _titleController.text.trim(),
                                  description: _descController.text.trim(),
                                  category: _selectedCategory,
                                  priority: _selectedPriority,
                                  dueDate: _selectedDueDate!,
                                ));
                              }
                            });

                            Navigator.pop(ctx); // Close the bottom sheet
                          },
                          child: Text(
                              existingTask != null ? 'Save Changes' : 'Add Task'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // Helper for consistent text field decoration
  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, size: 20),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    final tasks = _displayedTasks; // Get the filtered + sorted list

    return Scaffold(
      appBar: AppBar(
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  hintText: 'Search tasks...',
                  hintStyle: TextStyle(color: Colors.white60),
                  border: InputBorder.none,
                ),
                onChanged: (val) => setState(() => _searchQuery = val),
              )
            : const Text('My Tasks'),
        centerTitle: true,
        actions: [
          // Toggle search bar
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search),
            tooltip: 'Search',
            onPressed: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) {
                  _searchQuery = '';
                  _searchController.clear();
                }
              });
            },
          ),

          // Sort icon with dropdown menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            tooltip: 'Sort',
            onSelected: (value) => setState(() => _sortMode = value),
            itemBuilder: (_) => [
              const PopupMenuItem(
                  value: 'Date', child: Text('Sort by Due Date')),
              const PopupMenuItem(
                  value: 'Priority', child: Text('Sort by Priority')),
            ],
          ),

          // Clear all tasks icon
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            tooltip: 'Clear All',
            onPressed: _allTasks.isEmpty ? null : _clearAllTasks,
          ),
        ],
      ),

      body: Column(
        children: [
          // ── Statistics Bar ──
          Container(
            color: Colors.grey.shade100,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _statItem('Total', _totalCount, Colors.blueGrey),
                    _statItem('Completed', _completedCount, Colors.green),
                    _statItem('Pending', _pendingCount, Colors.orange),
                    Text(
                      '${(_completionRate * 100).toStringAsFixed(0)}%',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Linear progress bar showing completion percentage
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _completionRate,
                    minHeight: 8,
                    backgroundColor: Colors.grey.shade300,
                    valueColor: const AlwaysStoppedAnimation<Color>(
                        Color(0xFF2E7D32)),
                  ),
                ),
              ],
            ),
          ),

          // ── Filter Buttons ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: ['All', 'Pending', 'Completed'].map((filter) {
                final bool isActive = _activeFilter == filter;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _activeFilter = filter),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: isActive
                            ? const Color(0xFF2E7D32)
                            : Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        filter,
                        style: TextStyle(
                          color: isActive ? Colors.white : Colors.grey[700],
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          // ── Task List ──
          Expanded(
            child: tasks.isEmpty
                ? _emptyState()
                : ListView.builder(
                    itemCount: tasks.length,
                    padding: const EdgeInsets.only(bottom: 80),
                    itemBuilder: (context, index) {
                      final task = tasks[index];

                      // Dismissible makes a widget swipeable for deletion
                      return Dismissible(
                        key: ValueKey(task), // Unique key for each item
                        direction: DismissDirection.endToStart, // Swipe left
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          margin: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(Icons.delete_outline,
                              color: Colors.white, size: 28),
                        ),
                        onDismissed: (_) => _deleteTask(task),
                        child: TaskCard(
                          task: task,
                          onToggleComplete: () => _toggleTask(task),
                          onTap: () async {
                            // Navigate to detail screen and wait for result
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TaskDetailScreen(
                                  task: task,
                                  onDelete: () => _deleteTask(task),
                                  onEdit: () => _openTaskForm(existingTask: task),
                                  onToggle: () => _toggleTask(task),
                                ),
                              ),
                            );
                            setState(() {}); // Refresh after returning
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),

      // FAB to open Add Task form
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTaskForm(),
        icon: const Icon(Icons.add),
        label: const Text('Add Task'),
      ),
    );
  }

  // Displayed when the task list is empty
  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inbox_outlined, size: 72, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            _activeFilter == 'All'
                ? 'No tasks yet!\nTap + to add your first task.'
                : 'No $_activeFilter tasks.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade500,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // A small column showing a stat number and its label
  Widget _statItem(String label, int count, Color color) {
    return Column(
      children: [
        Text(
          '$count',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 11, color: Colors.grey[600]),
        ),
      ],
    );
  }
}
